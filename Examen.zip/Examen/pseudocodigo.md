objeto Persona * 10
Cada persona puede elegir entre bebida
cada persona = nombre, edad y nº de bebidas(carro de compra)
al menos 5 persona edad > 18

objeto bebida * 10
Cada bebida = nombre, marca, alcoho bool
5 tienen alcohol






 